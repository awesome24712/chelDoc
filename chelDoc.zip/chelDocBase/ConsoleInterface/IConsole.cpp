#include "IConsole.h"

IConsole* g_pConsole;

ConVar con_devmsg("con_devmsg", "1", "Whether or not to display developer messages in console");