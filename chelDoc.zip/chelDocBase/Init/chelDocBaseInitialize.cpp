#include "chelDocBaseInitialize.h"

bool g_bHasInit = false;
void NInitializations::ChelDocBase() {
	if (!g_bHasInit) {
		g_bHasInit = true;
		ChelTypes();
	}
}