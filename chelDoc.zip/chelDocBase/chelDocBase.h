#ifndef CHEL_DOC_BASE
#define CHEL_DOC_BASE

#include "Task/CTask.h"
#include "CDXML/CDXML.h"
#include "CFGLoader/NCFGLoad.h"
#include "Init/chelDocBaseInitialize.h"

#endif //CHEL_DOC_BASE