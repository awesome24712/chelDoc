#ifndef CHEL_NCFGLOAD
#define CHEL_NCFGLOAD

namespace NCFGLoad{
	void fromFile(const char* pszPath);
}

#endif //CHEL_NCFGLOAD