#ifndef CHEL_CHESS_BASE
#define CHEL_CHESS_BASE

#include "../chelTypes/chelTypes.hpp"
#include "../chelMath/chelMath.hpp"

#endif //CHEL_CHESS_BASE