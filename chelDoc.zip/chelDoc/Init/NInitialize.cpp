#include "Init/NInitialize.h"
#include "../chelConsole/chelConsole.h"
#include "../chelInterp/chelInterp.h"
#include "../chelWeb/chelWeb.h"
#include "../chelTester/Init/chelTesterInitialize.h"

namespace NChelDoc {
	void Initialize() {
		LoadCommonConfigs();
		LoadRuntimeLibraries();
	}
	
	void LoadCommonConfigs() {
		//get startup directory
		NCFGLoad::fromFile("autoexec.cfg");
		
		NCFGLoad::fromFile("interp.cfg");
		
		NCFGLoad::fromFile("web.cfg");
	}
	
	void LoadRuntimeLibraries() {
		//TODO make CTask for file in confif folder and dispatch that
		//to the NDynamicLoader!
		
		//CTask* cfgFiles;
		//NDynamicLoad::loadFromCfgFiles(cfgFiles);
		
	}
	
	void LoadConfigForLang(const String& langName) {
		//get startup directory
		String loc;
		NDirectoryScanner::startupDirectory(loc);
		loc /= "config/";
		loc /= langName;
		NCFGLoad::fromFile(loc);
	}
}

bool g_bHasInit = false;
void NInitializations::ChelDoc() {
	if (!g_bHasInit) {
		g_bHasInit = true;
		ChelMath();
		ChelTypes();
		ChelTester();
		ChelDocBase();
		ChelConsole();
		ChelProjectScanner();
		ChelInterpBase();
		ChelInterp();
		ChelWeb();
		
		NChelDoc::Initialize();
	}
}