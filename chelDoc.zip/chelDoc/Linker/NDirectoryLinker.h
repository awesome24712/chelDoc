#ifndef CHEL_DIRECTORY_LINKER
#define CHEL_DIRECTORY_LINKER

namespace NChelDoc {
	
}

#endif //CHEL_DIRECTORY_LINKER