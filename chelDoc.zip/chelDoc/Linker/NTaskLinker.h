#ifndef CHEL_TASK_LINKER
#define CHEL_TASK_LINKER

namespace NChelDoc {
	void generateFromTask();
}

#endif //CHEL_TASK_LINKER