#include <stdio.h>
#include "../chelMath/chelMath.hpp"

int main(int argc, char **argv)
{
	RandSeed();
	printf("Random number is %i\n", RandInt());
}
