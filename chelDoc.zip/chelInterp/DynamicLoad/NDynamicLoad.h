#ifndef CHEL_NDYNAMICLOAD
#define CHEL_NDYNAMICLOAD

#include "../../chelInterpBase/IInterp/IInterp.h"
//look in cfg folder, load proper cfg files, load interp folder with same name

namespace NDynamicLoad {
	
	void loadFromCfgFiles(CTask* cfgFiles);
}
#endif //CHEL_NDYNAMICLOAD