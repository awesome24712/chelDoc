#ifndef CHEL_INTERP
#define CHEL_INTERP

#include "DynamicLoad/NDynamicLoad.h"
#include "Init/chelInterpInitialize.h"

#endif //CHEL_INTERP