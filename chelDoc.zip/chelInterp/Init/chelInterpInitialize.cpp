#include "chelInterpInitialize.h"
#include "../chelInterpBase/Init/chelInterpBaseInitialize.h"

bool g_bHasInit = false;
void NInitializations::ChelInterp() {
	if (!g_bHasInit) {
		g_bHasInit = true;
		ChelDocBase();
		ChelProjectScanner();
		ChelInterpBase();
	}
}