#ifndef CHEL_INTERP_BASE_H
#define CHEL_INTERP_BASE_H

#include "IInterp/IInterp.h"
#include "Init/chelInterpBaseInitialize.h"

#endif //CHEL_INTERP_BASE_H