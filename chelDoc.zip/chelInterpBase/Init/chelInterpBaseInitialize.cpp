#include "chelInterpBaseInitialize.h"

bool g_bHasInit = false;
void NInitializations::ChelInterpBase() {
	if (!g_bHasInit) {
		g_bHasInit = true;
		ChelDocBase();
	}
}