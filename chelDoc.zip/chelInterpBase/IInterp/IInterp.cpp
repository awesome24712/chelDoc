#include "IInterp.h"

CDynList<IInterp*> g_lInterpreters;