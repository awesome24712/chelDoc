#ifndef CHEL_WEB_H
#define CHEL_WEB_H

#include "Generator/NGenerator.h"
#include "Init/chelWebInitialize.h"

#endif //CHEL_WEB_H