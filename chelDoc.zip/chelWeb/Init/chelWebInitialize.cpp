#include "chelWebInitialize.h"

bool g_bHasInit = false;
void NInitializations::ChelWeb() {
	if (!g_bHasInit) {
		g_bHasInit = true;
		ChelDocBase();
	}
}