#include "chelProjectScannerInitialize.h"

bool g_bHasInit = false;
void NInitializations::ChelProjectScanner() {
	if (!g_bHasInit) {
		g_bHasInit = true;
		ChelDocBase();
	}
}