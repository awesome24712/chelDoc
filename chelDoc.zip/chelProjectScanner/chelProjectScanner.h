#ifndef CHEL_PROJECT_SCANNER
#define CHEL_PROJECT_SCANNER

#include "Directory/NDirectoryScanner.h"
#include "Init/chelProjectScannerInitialize.h"

#endif //CHEL_PROJECT_SCANNER